import { storiesOf } from '@storybook/react';

export {
  storiesOf
}